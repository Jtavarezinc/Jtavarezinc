#!/usr/bin/env bash
set -e
git init
git branch -M main || true
git add .
git commit -m "JTAVAREZ site initial publish" || true
if [ -z "$1" ]; then
  echo "Usage: ./deploy.sh https://github.com/YOUR-USER/jtavarez-site.git"
  exit 1
fi
git remote remove origin 2>/dev/null || true
git remote add origin "$1"
git push -u origin main
