# JTAVAREZ INC — Website

Static site ready for free hosting.

## Structure
- `index.html` — landing page (black & gold theme) with autoplay slider
- `assets/` — your 8 project photos

## Contact (already in page)
- Phone: (954) 669-7928
- Email: jtavarezinc@gmail.com
- Area: South Florida (Broward to Palm Beach)

## Option A — Publish on GitHub Pages
1. Create a new public repo (e.g., `jtavarez-site`) on GitHub.
2. Upload *all* files and folders from this project.
3. In the repo: **Settings → Pages → Source: `main`**. Save.
4. After a minute: https://YOUR-USER.github.io/jtavarez-site

### Via Git
```bash
git init
git branch -M main
git add .
git commit -m "JTAVAREZ site initial publish"
git remote add origin https://github.com/YOUR-USER/jtavarez-site.git
git push -u origin main
```

## Option B — Publish on Netlify (drag & drop)
1. Go to https://app.netlify.com → **Add new site → Deploy manually**.
2. Drag the whole folder into the drop area.
3. Done. Your site will be live at https://<random-name>.netlify.app

## Custom Domain (optional)
- GitHub Pages: Settings → Pages → Custom domain (`jtavarez.com`)
- Netlify: Site settings → Domain management → Add domain

## Update Content
- Replace images inside `assets/` to change the slider and gallery.
- Edit text inside `index.html` (e.g., CTA, copy, hours).

---

© 2025 JTAVAREZ INC
